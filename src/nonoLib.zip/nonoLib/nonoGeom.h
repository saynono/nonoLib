/*
 *  nonoGeom.h
 *  LaserShapes_01
 *
 *  Created by Vincent R. on 21.12.09.
 *  Copyright 2009 www.say-nono.com. All rights reserved.
 *
 */



#ifndef _NONOGEOM
#define _NONOGEOM

#include "nonoMath.h"
#include "nonoPoint.h"

class nonoGeom{
	
public:

	
	
	
	static void multiply(nonoPoint *p, double val, nonoPoint *res = NULL){
		if(res == NULL) res = p;
		res->x = p->x * val;
		res->y = p->y * val;
	}
	
	static void divide(nonoPoint *p, double val, nonoPoint *res = NULL){
		multiply(p,1.0/val,res);
	}
	
	
	static double getAngle(nonoPoint *p){
		return nonoMath::angle(p->x, p->y);
	}
	
	static void rotate(nonoPoint *p, double angle, nonoPoint *res = NULL){
		nonoMath::rotatePoint(p, angle,res);
		/*
		 if(res == NULL) res = p;
		 var p:Point = nonoMath::rotatePoint(p, angle,res);
		 x = p.x;
		 y = p.y;
		 */
	}
	
	static void rotateZ(nonoPoint *p, double angle, nonoPoint *res = NULL){
		if(res == NULL) res = p;
		nonoMath::rotateCoordinates(p->x,p->y, angle,res);
	}
	
	static void rotateX(nonoPoint *p, double angle, nonoPoint *res = NULL){
		if(res == NULL) res = p;
		double x = res->x;
		double y = res->y;
		double z = res->z;
		nonoMath::rotateCoordinates(p->y,p->z, angle,res);
		y = res->x;
		z = res->y;
		res->x = x;
		res->y = y;
		res->z = z;
	}
	
	static void rotateY(nonoPoint *p, double angle, nonoPoint *res = NULL){
		if(res == NULL) res = p;
		double x = res->x;
		double y = res->y;
		double z = res->z;
		nonoMath::rotateCoordinates(p->x,p->z, angle,res);
		x = res->x;
		z = res->y;
		res->x = x;
		res->y = y;
		res->z = z;
	}
		
	static double getLength(nonoPoint *p, nonoPoint *p2 = NULL){
		double l;
		if(p2 == NULL) l = sqrt(p->x*p->x + p->y*p->y + p->z*p->z);
		else{
			double x = p2->x-p->x;
			double y = p2->y-p->y;
			double z = p2->z-p->z;
			l = sqrt(x*x+y*y+z*z);
		}
		return l;
	}
	
	static void addLength(nonoPoint *p, double len, nonoPoint *res = NULL){
		if(res == NULL) res = p;
		double l = getLength(p) + len;
		double a = nonoMath::angle(p->x, p->y);
		res->x = nonoMath::mySin(a)*l;
		res->y = nonoMath::myCos(a)*l;			
	}
	 
	static void addPoint(nonoPoint *p, nonoPoint *res){
		res->x += p->x;
		res->y += p->y;
		res->z += p->z;
	}
	
	 
	static void interpolate(nonoPoint *p1, nonoPoint *p2, double value, nonoPoint *res){
		res->x = nonoMath::interpolatedouble(p1->x, p2->x, value);
		res->y = nonoMath::interpolatedouble(p1->y, p2->y, value);
		res->z = nonoMath::interpolatedouble(p1->z, p2->z, value);
	}
	 
	 
	 static void normalise(nonoPoint *p) {
		 double d = getLength(p);
		 p->x /= d;
		 p->y /= d;
		 p->z /= d;
	 }
	 	 
	static void add(nonoPoint *p, double len, nonoPoint *res = NULL){
		if(res == NULL) res = p;
		res->x += p->x + len;
		res->y += p->y + len;
		res->z += p->z + len;
	 }
	 
	static void add(nonoPoint *p, nonoPoint *p2, nonoPoint *res = NULL){
		if(res == NULL) res = p;
		res->x += p->x + p2->x;
		res->y += p->y + p2->y;
		res->z += p->z + p2->z;
	}
	
	static void subtract(nonoPoint *p, double len, nonoPoint *res = NULL){
		if(res == NULL) res = p;
		res->x += p->x - len;
		res->y += p->y - len;
		res->z += p->z - len;
	}
	
	static void subtract(nonoPoint *p, nonoPoint *p2, nonoPoint *res = NULL){
		if(res == NULL) res = p;
		res->x += p->x - p2->x;
		res->y += p->y - p2->y;
		res->z += p->z - p2->z;
	}
	
	
	
	static void normal(nonoPoint *p1, nonoPoint *p2,nonoPoint *p3, nonoPoint *res){
		
/*		var v:NonoPoint = new NonoPoint();
		var v1:NonoPoint = p2.copy();
		var v2:NonoPoint = p3.copy();
		v1.subtractMe(p1);
		v2.subtractMe(p1);
		v->x = (v1.y*v2.z) - (v1.z*v2.y);
		v->y = (v1.z*v2.x) - (v1.x*v2.z);
		v->z = (v1.x*v2.y) - (v1.y*v2.x);
*/		
		double v1x = p2->x-p1->x;
		double v1y = p2->y-p1->y;
		double v1z = p2->z-p1->z;
		double v2x = p3->x-p1->x;
		double v2y = p3->y-p1->y;
		double v2z = p3->z-p1->z;
		
		res->x = (v1y*v2z) - (v1z*v2y);
		res->y = (v1z*v2x) - (v1x*v2z);
		res->z = (v1x*v2y) - (v1y*v2x);
		
		double d = nonoGeom::getLength(res);
		nonoGeom::multiply(res,1.0/d);
	}	
	
	static void center(nonoPoint **points, int amount, nonoPoint *res){
		for (int i = 0; i < amount; i++) {
			res->x += points[i]->x;
			res->y += points[i]->y;
			res->z += points[i]->z;
		}
		nonoGeom::divide(res,amount);
	}
	
};

#endif _NONOGEOM