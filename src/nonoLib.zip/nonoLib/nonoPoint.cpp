/*
 *  nonoPoint.cpp
 *  LaserShapes_01
 *
 *  Created by Vincent R. on 20.12.09.
 *  Copyright 2009 www.say-nono.com. All rights reserved.
 *
 */

#include "nonoPoint.h"

nonoPoint::nonoPoint(){
	x = 0;
	y = 0;
	z = 0;
}


nonoPoint::nonoPoint(float x_, float y_){
	x = x_;
	y = y_;
	z = 0;
}


nonoPoint::nonoPoint(float x_, float y_, float z_){
	x = x_;
	y = y_;
	z = z_;
}

//float* nonoPoint::toFloatArray(){
//	float arr[3] = {(float)x,(float)y,(float)z};
//	return arr;
//}
