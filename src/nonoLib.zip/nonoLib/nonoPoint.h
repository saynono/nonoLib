/*
 *  nonoPoint.h
 *  LaserShapes_01
 *
 *  Created by Vincent R. on 20.12.09.
 *  Copyright 2009 www.say-nono.com. All rights reserved.
 *
 */


#ifndef _NONOPOINT
#define _NONOPOINT

class nonoPoint{
	
public:
	float x;
	float y;
	float z;	
	
	nonoPoint();
	nonoPoint(float x, float y);
	nonoPoint(float x, float y, float z);
	
//	float* toFloatArray();
	
};

#endif